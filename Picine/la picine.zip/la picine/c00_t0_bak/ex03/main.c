void	ft_print_number(void);

int	main(void)
{
	ft_print_number();
	return (0);
}
