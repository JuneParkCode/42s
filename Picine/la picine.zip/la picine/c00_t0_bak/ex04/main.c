void	ft_is_negative(int n);

int	main(void)
{
	int	i;
	int	j;
	int	k;

	i = -2147483648;
	j = 0;
	k = 2147483647;
	ft_is_negative(i);
	ft_is_negative(j);
	ft_is_negative(k);
}
