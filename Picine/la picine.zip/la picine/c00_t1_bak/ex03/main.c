void	ft_print_numbers(void);

int	main(void)
{
	ft_print_numbers();
	return (0);
}
