#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <unistd.h>
void	ft_putnbr(int nb);

int	main(void)
{
	ft_putnbr(-12);
//	for	(int i = INT_MIN; i < INT_MAX; i += 5570645)
//	{
	//	ft_putnbr(i);
	//	write(1, "\n", 1);
//	}
	return (0);
}
