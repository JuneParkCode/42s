#include <stdio.h>
int ft_ten_queens_puzzle(void);

int	main(void)
{
	printf("%d", ft_ten_queens_puzzle());
	return (0);
}
